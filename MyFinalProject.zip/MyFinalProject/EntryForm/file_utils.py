import os


def save_student_image(image_file):
    image_folder = '/image.'  # Specify the path to your image folder

    with open(os.path.join(image_folder, image_file.name), 'wb+') as destination:
        for chunk in image_file.chunks():
            destination.write(chunk)


    