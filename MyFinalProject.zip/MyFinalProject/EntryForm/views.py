from django.shortcuts import render, redirect
from django.contrib import messages
from .forms import StudentForm, StudentSearchForm
from .models import Student

def index(request):
    return render(request, 'student/index.html')

def add_student(request):
    if request.method == "POST":
        form = StudentForm(request.POST, request.FILES)
        if form.is_valid():
            form.save()
            messages.success(request, 'Student added successfully.')
            return redirect('index')
        else:
            messages.error(request, 'Form data is invalid.')
    else:
        form = StudentForm()
        
    return render(request, "student/add_student.html", {"form": form})

def search_student(request):
    search_form = StudentSearchForm()
    search_results = None

    if 'search_query' in request.GET:
        search_form = StudentSearchForm(request.GET)
        if search_form.is_valid():
            search_query = search_form.cleaned_data['search_query'].strip()

            if search_query:
                search_results = Student.objects.filter(first_name__icontains=search_query)
                if not search_results:
                    messages.info(request, 'No student found with the matching first name.')
            else:
                messages.info(request, 'Please enter a character or string.')
    
    return render(request, "student/search_student.html", {"search_form": search_form, "search_results": search_results})
